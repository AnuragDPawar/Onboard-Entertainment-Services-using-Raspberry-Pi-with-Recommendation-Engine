<?php
$dbconnect = mysqli_connect("localhost","root","","project"); 


if(mysqli_connect_error())
	echo "Erro".mysqli_connect_errno();
exit;
?>