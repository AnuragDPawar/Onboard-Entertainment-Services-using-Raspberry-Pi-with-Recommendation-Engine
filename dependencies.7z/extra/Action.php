

<!DOCTYPE HTML>
<html>
<?php 
session_start();
$userid = $_SESSION['userid'];
$user_profile = $_SESSION['user_profile'];
include("header.php");
$dbconnect = mysqli_connect("localhost","root","","project"); 
$rand = mt_rand(1,10);
$passed_array = unserialize($_POST['input_name']);
echo $user_profile[0];
?>






<?php
	$vid_sql= "SELECT * FROM hindi as h , url as u WHERE h.uid=u.uid AND u.1>6";
	$vid_que=mysqli_query($dbconnect,$vid_sql);
	$vid_rh=mysqli_fetch_assoc($vid_que);
	$i=1;
	$n=mysqli_num_rows($vid_que);
	do
	{
		$ah[$i]=$vid_rh['id'];
			echo $ah[$i];
		$i++;
        		
	}while($vid_rh=mysqli_fetch_assoc($vid_que))
?>


<?php
	$vid_sql= "SELECT * FROM hindi as h , url as u WHERE h.uid=u.uid AND u.1>6";
	$vid_que=mysqli_query($dbconnect,$vid_sql);
	$vid_rh=mysqli_fetch_assoc($vid_que);
	$i=1;
	$n=mysqli_num_rows($vid_que);
	do
	{
		$ae[$i]=$vid_rh['id'];
			echo $ah[$i];
		$i++;
        		
	}while($vid_rh=mysqli_fetch_assoc($vid_que))
?>












 
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				  <?php $i=mt_rand(1,2);?>
				
				<div class="recommended">
					<div class="recommended-grids">
						<div class="recommended-info">
							<h3>Top English Movies</h3>
						</div>
						<script src="js/responsiveslides.min.js"></script>
						 <script>
							// You can also use "$(window).load(function() {"
							$(function () {
							  // Slideshow 4
							  $("#slider3").responsiveSlides({
								auto: true,
								pager: false,
								nav: true,
								speed: 500,
								namespace: "callbacks",
								before: function () {
								  $('.events').append("<li>before event fired.</li>");
								},
								after: function () {
								  $('.events').append("<li>after event fired.</li>");
								}
							  });
						
							});
						  </script>
						<div  id="top" class="callbacks_container">
							<ul class="rslides" id="slider3">
								<li>
									<div class="animated-grids">
										<div class="col-md-3 resent-grid recommended-grid slider-first">
										

											<div class="resent-grid-img recommended-grid-img">
												<a href="single.php?id=<?php echo $ae[$i+1];?>&ref=<?php echo '0';?>"><img src="images/<?php echo $vid_rs['poster2'];?>" alt="" /></a>
												<div class="time small-time slider-time">
													<p>7:34</p>
												</div>
												<div class="clck small-clck">
													<span class="glyphicon glyphicon-time" aria-hidden="true"></span>
												</div>
											</div>
											<div class="resent-grid-info recommended-grid-info">
												<h5><a href="single.php?id=<?php echo $ae[$i+1];?>&ref=<?php echo '0';?>" class="title"><?php echo $vid_rs['name'];?></a></h5>
												<div class="slid-bottom-grids">
													<div class="slid-bottom-grid">
														<p class="author author-info"><a href="#" class="author"><?php echo $vid_rs['cast1'];?><?php echo ","?><?php echo $vid_rs['cast2'];?></a></p>
													</div>
													
													<div class="clearfix"> </div>
												</div>
											</div>
										</div>
										<div class="col-md-3 resent-grid recommended-grid slider-first">
										

											<div class="resent-grid-img recommended-grid-img">
												<a href="single.php?id=<?php echo $ae[$i+2];?>&ref=<?php echo '0';?>"><img src="images/<?php echo $vid_rs['poster2'];?>" alt="" /></a>
												<div class="time small-time slider-time">
													<p>6:23</p>
												</div>
												<div class="clck small-clck">
													<span class="glyphicon glyphicon-time" aria-hidden="true"></span>
												</div>
											</div>
											<div class="resent-grid-info recommended-grid-info">
												<h5><a href="single.php?id=<?php echo $ae[$i+2];?>&ref=<?php echo '0';?>" class="title"><?php echo $vid_rs['name'];?></a></h5>
												<div class="slid-bottom-grids">
													<div class="slid-bottom-grid">
														<p class="author author-info"><a href="#" class="author"><?php echo $vid_rs['cast1'];?><?php echo ","?><?php echo $vid_rs['cast2'];?></a></p>
													</div>
													
													<div class="clearfix"> </div>
												</div>
											</div>
										</div>
										<div class="col-md-3 resent-grid recommended-grid slider-first">
											<div class="resent-grid-img recommended-grid-img">
											

												<a href="single.php?id=<?php echo $ae[$i+3];?>&ref=<?php echo '0';?>"><img src="images/<?php echo $vid_rs['poster2'];?>" alt="" /></a>
												<div class="time small-time slider-time">
													<p>2:45</p>
												</div>
												<div class="clck small-clck">
													<span class="glyphicon glyphicon-time" aria-hidden="true"></span>
												</div>
											</div>
											<div class="resent-grid-info recommended-grid-info">
												<h5><a href="single.php?id=<?php echo $ae[$i+3];?>&ref=<?php echo '0';?>" class="title"><?php echo $vid_rs['name'];?></a></h5>
												<div class="slid-bottom-grids">
													<div class="slid-bottom-grid">
														<p class="author author-info"><a href="#" class="author"><?php echo $vid_rs['cast1'];?><?php echo ","?><?php echo $vid_rs['cast2'];?></a></p>
													</div>
													
													<div class="clearfix"> </div>
												</div>
											</div>
										</div>
										<div class="col-md-3 resent-grid recommended-grid slider-first">
										

											<div class="resent-grid-img recommended-grid-img">
												<a href="single.php?id=<?php echo $ae[$i+4];?>&ref=<?php echo '0';?>"><img src="images/<?php echo $vid_rs['poster2'];?>" alt="" /></a>
												<div class="time small-time slider-time">
													<p>4:34</p>
												</div>
												<div class="clck small-clck">
													<span class="glyphicon glyphicon-time" aria-hidden="true"></span>
												</div>
											</div>
											<div class="resent-grid-info recommended-grid-info">
												<h5><a href="single.php?id=<?php echo $ae[$i+4];?>&ref=<?php echo '0';?>" class="title"><?php echo $vid_rs['name'];?></a></h5>
												<div class="slid-bottom-grids">
													<div class="slid-bottom-grid">
														<p class="author author-info"><a href="#" class="author"><?php echo $vid_rs['cast1'];?><?php echo ","?><?php echo $vid_rs['cast2'];?></a></p>
													</div>
													
													<div class="clearfix"> </div>
												</div>
											</div>
										</div>
										<div class="clearfix"> </div>
									</div>
								</li>
								<li>
									<div class="animated-grids">
										<div class="col-md-3 resent-grid recommended-grid slider-first">
										

											<div class="resent-grid-img recommended-grid-img">
												<a href="single.php?id=<?php echo $ae[$i+5];?>&ref=<?php echo '0';?>"><img src="images/<?php echo $vid_rs['poster2'];?>" alt="" /></a>
												<div class="time small-time slider-time">
													<p>4:42</p>
												</div>
												<div class="clck small-clck">
													<span class="glyphicon glyphicon-time" aria-hidden="true"></span>
												</div>
											</div>
											<div class="resent-grid-info recommended-grid-info">
												<h5><a href="single.php?id=<?php echo $ae[$i+5];?>&ref=<?php echo '0';?>" class="title"><?php echo $vid_rs['name'];?></a></h5>
												<div class="slid-bottom-grids">
													<div class="slid-bottom-grid">
														<p class="author author-info"><a href="#" class="author"><?php echo $vid_rs['cast1'];?><?php echo ","?><?php echo $vid_rs['cast2'];?></a></p>
													</div>
													
													<div class="clearfix"> </div>
												</div>
											</div>
										</div>
										<div class="col-md-3 resent-grid recommended-grid slider-first">
										

											<div class="resent-grid-img recommended-grid-img">
												<a href="single.php?id=<?php echo $ae[$i+6];?>&ref=<?php echo '0';?>"><img src="images/<?php echo $vid_rs['poster2'];?>" alt="" /></a>
												<div class="time small-time slider-time">
													<p>6:14</p>
												</div>
												<div class="clck small-clck">
													<span class="glyphicon glyphicon-time" aria-hidden="true"></span>
												</div>
											</div>
											<div class="resent-grid-info recommended-grid-info">
												<h5><a href="single.php?id=<?php echo $ae[$i+6];?>&ref=<?php echo '0';?>" class="title"><?php echo $vid_rs['name'];?></a></h5>
												<div class="slid-bottom-grids">
													<div class="slid-bottom-grid">
														<p class="author author-info"><a href="#" class="author"><?php echo $vid_rs['cast1'];?><?php echo ","?><?php echo $vid_rs['cast2'];?></a></p>
													</div>
													
													<div class="clearfix"> </div>
												</div>
											</div>
										</div>
										<div class="col-md-3 resent-grid recommended-grid slider-first">
										

											<div class="resent-grid-img recommended-grid-img">
												<a href="single.php?id=<?php echo $ae[$i+7];?>&ref=<?php echo '0';?>"><img src="images/<?php echo $vid_rs['poster2'];?>" alt="" /></a>
												<div class="time small-time slider-time">
													<p>2:34</p>
												</div>
												<div class="clck small-clck">
													<span class="glyphicon glyphicon-time" aria-hidden="true"></span>
												</div>
											</div>
											<div class="resent-grid-info recommended-grid-info">
												<h5><a href="single.php?id=<?php echo $ae[$i+7];?>&ref=<?php echo '0';?>" class="title"><?php echo $vid_rs['name'];?></a></h5>
												<div class="slid-bottom-grids">
													<div class="slid-bottom-grid">
														<p class="author author-info"><a href="#" class="author"><?php echo $vid_rs['cast1'];?><?php echo ","?><?php echo $vid_rs['cast2'];?></a></p>
													</div>
													
													<div class="clearfix"> </div>
												</div>
											</div>
										</div>
										<div class="col-md-3 resent-grid recommended-grid slider-first">
										

											<div class="resent-grid-img recommended-grid-img">
												<a href="single.php?id=<?php echo $ae[$i+8];?>&ref=<?php echo '0';?>"><img src="images/<?php echo $vid_rs['poster2'];?>" alt="" /></a>
												<div class="time small-time slider-time">
													<p>5:12</p>
												</div>
												<div class="clck small-clck">
													<span class="glyphicon glyphicon-time" aria-hidden="true"></span>
												</div>
											</div>
											<div class="resent-grid-info recommended-grid-info">
												<h5><a href="single.php?id=<?php echo $ae[$i+8];?>&ref=<?php echo '0';?>" class="title"><?php echo $vid_rs['name'];?></a></h5>
												<div class="slid-bottom-grids">
													<div class="slid-bottom-grid">
														<p class="author author-info"><a href="#" class="author"><?php echo $vid_rs['cast1'];?><?php echo ","?><?php echo $vid_rs['cast2'];?></a></p>
													</div>
													
													<div class="clearfix"> </div>
												</div>
											</div>
										</div>
										<div class="clearfix"> </div>
									</div>
								</li>
								
							</ul>
						</div>
					</div>
				</div>
				
				
				
	
			<!-- footer -->
			<?php include("footer.php"); ?>
			<!-- //footer -->
		</div>
		<div class="clearfix"> </div>

    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="js/bootstrap.min.js"></script>
    <!-- Just to make our placeholder images work. Don't actually copy the next line! -->
  </body>
</html>